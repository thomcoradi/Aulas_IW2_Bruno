function login(){

    let login = ""
    let senha = "1234"


    let bclogin1 = "ana1"
    let bcsenha1 = "1234"

    let bclogin2 = "ana"
    let bcsenha2= "1234"

    let bclogin3 = "ana"
    let bcsenha3 = "1234"

     const vetorlg = [bclogin1,bclogin2,bclogin3]
     const vetorsn = [bcsenha1,bcsenha2,bcsenha3]

     leia 0 até a 1
     i = 0
     i = i + 1

    if(login == vetorlg[0] && senha == vetorsn[0]){


    }
}