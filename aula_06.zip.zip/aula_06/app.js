function dados(){
    //vetor:
    const ds = [
                {id:1,login:"Ringo",senha:"12345",email:"ringo@gmail.com"},
                {id:2,login:"Paul",senha:"12346",email:"paul@gmail.com"},
                {id:3,login:"John",senha:"12347",email:"john@gmail.com"}
                ]
    return ds    
}


function login(user,password){

    const usuarios = dados()

for(let i=0;i<usuarios.length;i++){
    if(user == usuarios[0].login && password == usuarios[0].senha){
        console.log("Você logou.")
        break
    } 
 }
}

function logar(){
    let lg = document.getElementById("login").value
    let sn = document.getElementById("senha").value

    login(lg,sn)
}
